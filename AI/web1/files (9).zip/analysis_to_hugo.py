#!/usr/bin/env python3
"""
Convert ocean model analysis results to Hugo website content.
Generates markdown files with frontmatter from statistics reports.
"""

import re
import yaml
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional
import json
import shutil


class AnalysisToHugo:
    """Convert analysis results to Hugo-compatible markdown."""
    
    def __init__(self, hugo_site_dir: str = "./hugo_site"):
        self.hugo_dir = Path(hugo_site_dir)
        self.content_dir = self.hugo_dir / "content" / "analyses"
        self.static_dir = self.hugo_dir / "static" / "analyses"
        self.content_dir.mkdir(parents=True, exist_ok=True)
        self.static_dir.mkdir(parents=True, exist_ok=True)
        
    def parse_statistics_report(self, report_file: str) -> Dict:
        """
        Parse statistics_report.txt and extract metrics.
        
        Returns:
        --------
        Dict with structure:
            {
                'metadata': {...},
                'variables': {
                    'sst': {'bias': ..., 'rmse': ..., ...},
                    'temperature': {...}
                }
            }
        """
        with open(report_file, 'r') as f:
            content = f.read()
        
        result = {
            'metadata': {},
            'variables': {}
        }
        
        # Extract regridding info
        if 'Regridding method:' in content:
            method = re.search(r'Regridding method:\s*(\w+)', content)
            direction = re.search(r'Regridding direction:\s*([\w_]+)', content)
            result['metadata']['regrid_method'] = method.group(1) if method else 'unknown'
            result['metadata']['regrid_direction'] = direction.group(1) if direction else 'unknown'
        
        # Split by variables
        variable_sections = re.split(r'={80}\nVARIABLE:', content)
        
        for section in variable_sections[1:]:  # Skip header
            var_match = re.match(r'\s*([^(]+)\s*\(([^)]+)\)', section)
            if not var_match:
                continue
            
            var_name = var_match.group(1).strip().lower().replace(' ', '_')
            var_type = var_match.group(2).strip()
            
            var_data = {
                'type': var_type,
                'full_name': var_match.group(1).strip()
            }
            
            # Extract overall statistics
            stats_section = re.search(r'OVERALL STATISTICS.*?(?=\n\n|DEPTH-DEPENDENT|$)', section, re.DOTALL)
            if stats_section:
                stats_text = stats_section.group(0)
                
                patterns = {
                    'obs_mean': r'Observed mean:\s*([-\d.]+)',
                    'model_mean': r'Model mean:\s*([-\d.]+)',
                    'bias': r'Bias \(Model - Obs\):\s*([-\d.]+)',
                    'rmse': r'RMSE:\s*([-\d.]+)',
                    'mae': r'MAE:\s*([-\d.]+)',
                    'correlation': r'Correlation:\s*([-\d.]+)'
                }
                
                for key, pattern in patterns.items():
                    match = re.search(pattern, stats_text)
                    if match:
                        var_data[key] = float(match.group(1))
            
            # Extract monthly statistics if present
            monthly_section = re.search(r'MONTHLY STATISTICS.*?(?=\n\n|$)', section, re.DOTALL)
            if monthly_section:
                var_data['has_monthly'] = True
            
            # Extract depth statistics for 3D
            depth_section = re.search(r'DEPTH-DEPENDENT STATISTICS', section)
            if depth_section:
                var_data['has_depth_profiles'] = True
            
            result['variables'][var_name] = var_data
        
        return result
    
    def create_analysis_page(
        self,
        analysis_dir: str,
        model_name: str,
        metadata_file: Optional[str] = None,
        slug: Optional[str] = None
    ):
        """
        Create Hugo content page from an analysis directory.
        
        Parameters:
        -----------
        analysis_dir : str
            Path to analysis output directory (contains statistics_report.txt)
        model_name : str
            Name of the model
        metadata_file : str, optional
            Path to additional metadata markdown file
        slug : str, optional
            URL slug (auto-generated if None)
        """
        analysis_path = Path(analysis_dir)
        
        if not analysis_path.exists():
            raise ValueError(f"Analysis directory not found: {analysis_dir}")
        
        # Find statistics report
        stats_report = analysis_path / "statistics_report.txt"
        if not stats_report.exists():
            raise ValueError(f"No statistics_report.txt found in {analysis_dir}")
        
        # Parse statistics
        stats_data = self.parse_statistics_report(stats_report)
        
        # Generate slug
        if slug is None:
            slug = f"{model_name.lower().replace(' ', '-')}-{datetime.now().strftime('%Y%m%d')}"
        
        # Create frontmatter
        frontmatter = {
            'title': f"{model_name} Validation",
            'date': datetime.now().isoformat(),
            'model': model_name,
            'variables': list(stats_data['variables'].keys()),
            'metrics': {
                var: {
                    'bias': data.get('bias', None),
                    'rmse': data.get('rmse', None),
                    'correlation': data.get('correlation', None)
                }
                for var, data in stats_data['variables'].items()
            },
            'regrid_method': stats_data['metadata'].get('regrid_method', 'unknown'),
            'regrid_direction': stats_data['metadata'].get('regrid_direction', 'unknown'),
            'draft': False
        }
        
        # Load additional metadata if provided
        extra_metadata = ""
        if metadata_file and Path(metadata_file).exists():
            with open(metadata_file, 'r') as f:
                extra_metadata = f.read()
                
                # Try to extract YAML frontmatter from metadata file
                if extra_metadata.startswith('---'):
                    parts = extra_metadata.split('---', 2)
                    if len(parts) >= 3:
                        try:
                            extra_yaml = yaml.safe_load(parts[1])
                            frontmatter.update(extra_yaml)
                            extra_metadata = parts[2].strip()
                        except:
                            pass
        
        # Copy images to static directory
        static_analysis_dir = self.static_dir / slug
        static_analysis_dir.mkdir(parents=True, exist_ok=True)
        
        image_files = []
        for var_dir in analysis_path.iterdir():
            if var_dir.is_dir():
                for img in var_dir.glob("*.png"):
                    dest = static_analysis_dir / f"{var_dir.name}_{img.name}"
                    shutil.copy2(img, dest)
                    image_files.append({
                        'variable': var_dir.name,
                        'filename': img.name,
                        'path': f"/analyses/{slug}/{var_dir.name}_{img.name}"
                    })
        
        frontmatter['images'] = image_files
        
        # Build markdown content
        content = f"""---
{yaml.dump(frontmatter, default_flow_style=False)}---

# {model_name} Model Validation

{extra_metadata}

## Analysis Summary

**Analysis Date:** {datetime.now().strftime('%Y-%m-%d')}  
**Regridding Method:** {stats_data['metadata'].get('regrid_method', 'N/A')}  
**Regridding Direction:** {stats_data['metadata'].get('regrid_direction', 'N/A')}

## Variables Analyzed

"""
        
        # Add variable summaries
        for var_name, var_data in stats_data['variables'].items():
            content += f"""### {var_data['full_name']} ({var_data['type']})

| Metric | Value |
|--------|-------|
| Bias (Model - Obs) | {var_data.get('bias', 'N/A'):.4f} |
| RMSE | {var_data.get('rmse', 'N/A'):.4f} |
| Correlation | {var_data.get('correlation', 'N/A'):.4f} |
| MAE | {var_data.get('mae', 'N/A'):.4f} |

"""
        
        # Add visualizations
        content += "\n## Visualizations\n\n"
        
        for var_name in stats_data['variables'].keys():
            var_images = [img for img in image_files if img['variable'] == var_name]
            if var_images:
                content += f"\n### {var_name.upper()}\n\n"
                for img in var_images:
                    img_title = img['filename'].replace('.png', '').replace('_', ' ').title()
                    content += f"#### {img_title}\n\n"
                    content += f"![{img_title}]({img['path']})\n\n"
        
        # Add full statistics report
        content += "\n## Full Statistics Report\n\n"
        content += "```\n"
        with open(stats_report, 'r') as f:
            content += f.read()
        content += "\n```\n"
        
        # Write markdown file
        output_file = self.content_dir / f"{slug}.md"
        with open(output_file, 'w') as f:
            f.write(content)
        
        print(f"Created analysis page: {output_file}")
        return slug, frontmatter
    
    def create_index_page(self, analyses: List[Dict]):
        """Create master index page listing all analyses."""
        
        content = """---
title: "All Model Analyses"
layout: "list"
---

# Ocean Model Validation Analyses

Browse all model validation analyses below. Results are organized by model and can be filtered by variable, metric, or analysis date.

"""
        
        # Group by model
        by_model = {}
        for analysis in analyses:
            model = analysis.get('model', 'Unknown')
            if model not in by_model:
                by_model[model] = []
            by_model[model].append(analysis)
        
        for model, model_analyses in sorted(by_model.items()):
            content += f"\n## {model}\n\n"
            for analysis in sorted(model_analyses, key=lambda x: x.get('date', ''), reverse=True):
                content += f"- [{analysis['title']}]({analysis['slug']}) "
                content += f"({analysis.get('date', 'N/A')[:10]})\n"
                content += f"  - Variables: {', '.join(analysis.get('variables', []))}\n"
        
        output_file = self.content_dir / "_index.md"
        with open(output_file, 'w') as f:
            f.write(content)
        
        print(f"Created index page: {output_file}")


class ModelRanking:
    """Generate model rankings based on multiple statistics."""
    
    def __init__(self, hugo_site_dir: str = "./hugo_site"):
        self.hugo_dir = Path(hugo_site_dir)
        self.rankings_dir = self.hugo_dir / "content" / "rankings"
        self.rankings_dir.mkdir(parents=True, exist_ok=True)
    
    def collect_all_metrics(self, analyses: List[Dict]) -> Dict:
        """
        Collect all metrics from multiple analyses.
        
        Returns:
        --------
        Dict structure:
            {
                'sst': {
                    'model1': {'bias': ..., 'rmse': ..., ...},
                    'model2': {...}
                },
                'temperature': {...}
            }
        """
        metrics_by_variable = {}
        
        for analysis in analyses:
            model_name = analysis.get('model', 'Unknown')
            
            for var_name, var_metrics in analysis.get('metrics', {}).items():
                if var_name not in metrics_by_variable:
                    metrics_by_variable[var_name] = {}
                
                if model_name not in metrics_by_variable[var_name]:
                    metrics_by_variable[var_name][model_name] = {}
                
                metrics_by_variable[var_name][model_name].update(var_metrics)
        
        return metrics_by_variable
    
    def calculate_composite_score(
        self, 
        metrics: Dict[str, float],
        weights: Optional[Dict[str, float]] = None
    ) -> float:
        """
        Calculate composite score from multiple metrics.
        
        Lower is better. Normalizes each metric and combines.
        """
        if weights is None:
            # Default weights
            weights = {
                'bias': 0.2,      # Absolute bias
                'rmse': 0.4,      # RMSE (most important)
                'mae': 0.2,       # MAE
                'correlation': 0.2  # 1 - correlation (so lower is better)
            }
        
        score = 0.0
        total_weight = 0.0
        
        for metric, weight in weights.items():
            if metric in metrics and metrics[metric] is not None:
                value = metrics[metric]
                
                # For correlation, invert (1 - corr) so lower is better
                if metric == 'correlation':
                    value = 1.0 - value
                else:
                    # For bias, use absolute value
                    if metric == 'bias':
                        value = abs(value)
                
                score += value * weight
                total_weight += weight
        
        if total_weight > 0:
            return score / total_weight
        return float('inf')
    
    def rank_models(
        self,
        metrics_by_variable: Dict,
        weights: Optional[Dict[str, float]] = None
    ) -> Dict:
        """
        Rank models for each variable and overall.
        
        Returns:
        --------
        Dict with rankings:
            {
                'sst': [(model, score, rank), ...],
                'overall': [(model, avg_score, rank), ...]
            }
        """
        rankings = {}
        model_overall_scores = {}
        
        # Rank for each variable
        for var_name, model_metrics in metrics_by_variable.items():
            var_rankings = []
            
            for model, metrics in model_metrics.items():
                score = self.calculate_composite_score(metrics, weights)
                var_rankings.append((model, score, metrics))
            
            # Sort by score (lower is better)
            var_rankings.sort(key=lambda x: x[1])
            
            # Assign ranks
            ranked = [(model, score, idx + 1, metrics) 
                     for idx, (model, score, metrics) in enumerate(var_rankings)]
            
            rankings[var_name] = ranked
            
            # Accumulate for overall
            for model, score, rank, _ in ranked:
                if model not in model_overall_scores:
                    model_overall_scores[model] = []
                model_overall_scores[model].append(score)
        
        # Calculate overall rankings
        overall_rankings = []
        for model, scores in model_overall_scores.items():
            avg_score = sum(scores) / len(scores)
            overall_rankings.append((model, avg_score))
        
        overall_rankings.sort(key=lambda x: x[1])
        rankings['overall'] = [
            (model, score, idx + 1) 
            for idx, (model, score) in enumerate(overall_rankings)
        ]
        
        return rankings
    
    def create_ranking_page(self, rankings: Dict, analyses: List[Dict]):
        """Create ranking page in markdown and HTML."""
        
        # Markdown version
        md_content = """---
title: "Model Rankings"
date: {date}
layout: "rankings"
---

# Ocean Model Performance Rankings

Rankings are based on a composite score combining multiple metrics (RMSE, bias, MAE, correlation).
**Lower scores are better.**

""".format(date=datetime.now().isoformat())
        
        # Overall rankings
        md_content += "\n## Overall Rankings (All Variables)\n\n"
        md_content += "| Rank | Model | Composite Score |\n"
        md_content += "|------|-------|----------------|\n"
        
        for model, score, rank in rankings.get('overall', []):
            md_content += f"| {rank} | **{model}** | {score:.4f} |\n"
        
        # Rankings by variable
        for var_name in sorted(rankings.keys()):
            if var_name == 'overall':
                continue
            
            md_content += f"\n## {var_name.upper()} Rankings\n\n"
            md_content += "| Rank | Model | Score | RMSE | Bias | Correlation |\n"
            md_content += "|------|-------|-------|------|------|-------------|\n"
            
            for model, score, rank, metrics in rankings[var_name]:
                rmse = metrics.get('rmse', 'N/A')
                bias = metrics.get('bias', 'N/A')
                corr = metrics.get('correlation', 'N/A')
                
                rmse_str = f"{rmse:.4f}" if isinstance(rmse, (int, float)) else rmse
                bias_str = f"{bias:.4f}" if isinstance(bias, (int, float)) else bias
                corr_str = f"{corr:.4f}" if isinstance(corr, (int, float)) else corr
                
                md_content += f"| {rank} | **{model}** | {score:.4f} | {rmse_str} | {bias_str} | {corr_str} |\n"
        
        # Methodology
        md_content += """

## Ranking Methodology

### Composite Score Calculation

The composite score is calculated as a weighted combination of multiple metrics:

- **RMSE (40%)**: Root Mean Square Error - measures overall prediction accuracy
- **Bias (20%)**: Mean bias (absolute value) - measures systematic error
- **MAE (20%)**: Mean Absolute Error - measures average error magnitude
- **Correlation (20%)**: 1 - correlation coefficient - measures pattern agreement

**Score = 0.4×RMSE + 0.2×|Bias| + 0.2×MAE + 0.2×(1-Correlation)**

Lower scores indicate better model performance.

### Interpretation

- **Score < 0.5**: Excellent performance
- **Score 0.5-1.0**: Good performance
- **Score 1.0-2.0**: Moderate performance
- **Score > 2.0**: Needs improvement

"""
        
        # Write markdown
        md_file = self.rankings_dir / "index.md"
        with open(md_file, 'w') as f:
            f.write(md_content)
        
        print(f"Created ranking page: {md_file}")
        
        # Also export as JSON for interactive use
        json_data = {
            'generated': datetime.now().isoformat(),
            'rankings': {
                var: [
                    {
                        'model': model,
                        'rank': rank,
                        'score': score,
                        'metrics': metrics if len(item) > 3 else {}
                    }
                    for item in rankings[var]
                    for model, score, rank, *rest in [item]
                    for metrics in [rest[0] if rest else {}]
                ]
                for var in rankings.keys()
            }
        }
        
        json_file = self.hugo_dir / "static" / "rankings.json"
        with open(json_file, 'w') as f:
            json.dump(json_data, f, indent=2)
        
        print(f"Created ranking JSON: {json_file}")
        
        return md_file


def main():
    """Example usage."""
    
    # Initialize converters
    converter = AnalysisToHugo(hugo_site_dir="./hugo_site")
    ranker = ModelRanking(hugo_site_dir="./hugo_site")
    
    # Example: Add multiple analyses
    analyses = []
    
    # This would typically be done in a loop over your analysis directories
    example_analyses = [
        {
            'dir': './sst_output',
            'model': 'ROMS-Regional',
            'metadata': './roms_metadata.md'
        },
        {
            'dir': './nemo_output',
            'model': 'NEMO-Global',
            'metadata': './nemo_metadata.md'
        }
    ]
    
    for analysis in example_analyses:
        try:
            slug, frontmatter = converter.create_analysis_page(
                analysis_dir=analysis['dir'],
                model_name=analysis['model'],
                metadata_file=analysis.get('metadata')
            )
            
            frontmatter['slug'] = slug
            analyses.append(frontmatter)
            
        except Exception as e:
            print(f"Error processing {analysis['model']}: {e}")
    
    # Create index page
    converter.create_index_page(analyses)
    
    # Generate rankings
    metrics = ranker.collect_all_metrics(analyses)
    rankings = ranker.rank_models(metrics)
    ranker.create_ranking_page(rankings, analyses)
    
    print("\nWebsite content generated successfully!")
    print("Run 'hugo server' in the hugo_site directory to preview.")


if __name__ == "__main__":
    main()
